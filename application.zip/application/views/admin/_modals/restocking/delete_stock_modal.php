<?php if (!$this->session->userdata('UserRestrictions')['restocking_delete_stock']) return; ?>
<div class="modal fade" id="Modal_DeleteStock" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-trash" style="font-size: 20px; margin-right: 5px;"></i> Delete this Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="ajx_res_prompt">

        </div>
        <small>This stock will be deleted and cannot be retrieve.</small>
      </div>
      <div class="modal-footer">
        
        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x"></i> Cancel</button> -->
        <button id="btn_deleteStock" type="button" class="btn btn-primary" data-id=""><i class="bi bi-trash"></i> Delete Stock</button>
      </div>
    </div>
  </div>
</div>