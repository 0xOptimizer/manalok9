<div class="modal fade" id="databaseBackupPrompt" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content" style="height: 12em;">
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-12 col-md-6">
						<div class="card standard-card-btn standard-card-btn-primary">
							<a href="<?=base_url()?>database_backup" class="card-body text-center">
								<p class="card-btn-icon"><i class="bi bi-back"></i></p>
								<p class="card-btn-text">CREATE BACKUP</p>
							</a>
						</div>
					</div>
					<div class="col-sm-12 col-md-6">
						<div class="card standard-card-btn standard-card-btn-primary">
							<div class="card-body text-center">
								<p class="card-btn-icon"><i class="bi bi-stack"></i></p>
								<p class="card-btn-text">VIEW BACKUPS</p>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>