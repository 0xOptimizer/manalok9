<?php if (!$this->session->userdata('UserRestrictions')['products_delete']) return; ?>
<div class="modal" id="prompt_delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content modal-content-custom">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Move to Trash ?</h5>
      </div>
      <div class="modal-body">
        <span id="item_id" style="color: #E8A740;"></span><br>
        <small>this product will be move to Trash.</small>
      </div>
      <div class="modal-footer">
        <a id="movetoarchive" class="btn btn-primary" type="button" href="#"> Move</a>
        <a id="cancel_movetoarchive" class="btn btn-secondary" type="button" href="#"> Cancel</a>
      </div>
    </div>
  </div>
</div>