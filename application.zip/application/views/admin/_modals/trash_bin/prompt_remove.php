<?php if (!$this->session->userdata('UserRestrictions')['trash_bin_delete']) return; ?>
<div class="modal" id="prompt_remove" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content modal-content-custom">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Product Permanently ?</h5>
      </div>
      <div class="modal-body">
        <small>This product will be deleted and cannot be retrieve.</small>
      </div>
      <div class="modal-footer">
        <a id="delete_prd" class="btn btn-primary" type="button" href="#"> Delete</a>
        <a id="cancel_modaldelete" class="btn btn-secondary" type="button" href="#"> Cancel</a>
      </div>
    </div>
  </div>
</div>